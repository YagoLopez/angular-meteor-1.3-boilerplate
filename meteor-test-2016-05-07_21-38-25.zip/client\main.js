import angular from 'angular';
import angularMeteor from 'angular-meteor';

var app = angular.module('socially', [ angularMeteor]);

app.controller('PartiesListCtrl', function ($scope, $reactive, $meteor) {

    $reactive(this).attach($scope);

    this.helpers({
        parties(){
            return Parties.find();
        }
    });

    this.borrarTodas = function () {
        Meteor.call('borrarTodas');
    }
});